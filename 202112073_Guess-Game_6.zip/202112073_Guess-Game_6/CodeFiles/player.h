int myrecv(int sockfd, void *buff, int size, char *err_msg);

int mysend(int sockfd, void *msg, int len, char *err_msg);
