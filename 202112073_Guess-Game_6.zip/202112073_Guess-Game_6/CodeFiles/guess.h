#define PLAYERCOUNT 1
#define NAMELEN 100 
void sighandler(int);
void sig1handler(int);
void sig2handler(int);
void sigpinthandler(int);
void sigcinthandler(int);
int check_input(int n);
int is_correct(char *str);
int valid_str(char *str);
int connection_handler(int sockfd, char *buff);
void game_loop(int *players_fd, char players_names[PLAYERCOUNT][NAMELEN]);
int mysend(int sockfd, char *msg, int len, char *err_msg);
int myrecv(int sockfd, void *buff, int len, char *err_msg);
void sighandler(int sig);
void sig1handler(int signum);
void sig2handler(int signum);
void sigpinthandler(int signum);
void sigcinthandler(int signum);

